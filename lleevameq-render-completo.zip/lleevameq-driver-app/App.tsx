import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
  FlatList,
  ScrollView,
  Switch,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Provider, useSelector, useDispatch } from 'react-redux';
import { configureStore, createSlice } from '@reduxjs/toolkit';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { io } from 'socket.io-client';

// ==================== CONFIGURACIÓN ====================
const API_URL = 'http://localhost:3000/api'; // Cambiar por tu IP
const WS_URL = 'http://localhost:3000';

// ==================== SERVICIOS ====================
const apiClient = axios.create({
  baseURL: API_URL,
  timeout: 10000,
});

apiClient.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

const api = {
  login: async (email, password) => {
    const res = await apiClient.post('/auth/login', { email, password });
    await AsyncStorage.setItem('token', res.data.access_token);
    await AsyncStorage.setItem('user', JSON.stringify(res.data.user));
    return res.data;
  },
  register: async (data) => {
    const res = await apiClient.post('/auth/register', { ...data, role: 'driver' });
    await AsyncStorage.setItem('token', res.data.access_token);
    await AsyncStorage.setItem('user', JSON.stringify(res.data.user));
    return res.data;
  },
  getRides: () => apiClient.get('/rides?role=driver').then(r => r.data),
  getRideById: (id) => apiClient.get(`/rides/${id}`).then(r => r.data),
  assignRide: (id) => apiClient.post(`/rides/${id}/assign`).then(r => r.data),
  startRide: (id) => apiClient.post(`/rides/${id}/start`).then(r => r.data),
  completeRide: (id) => apiClient.post(`/rides/${id}/complete`).then(r => r.data),
  cancelRide: (id, reason) => apiClient.post(`/rides/${id}/cancel`, { reason }).then(r => r.data),
  updateStatus: (status) => apiClient.post('/users/driver/status', { status }).then(r => r.data),
  updateLocation: (lat, lng) => apiClient.post('/users/location', { lat, lng }).then(r => r.data),
  getStats: () => apiClient.get('/users/driver/stats').then(r => r.data),
};

// ==================== WEBSOCKET ====================
let socket = null;
const connectSocket = (userId) => {
  if (!socket) {
    socket = io(WS_URL);
    socket.on('connect', () => {
      socket.emit('authenticate', { userId });
      console.log('Socket conectado');
    });
  }
  return socket;
};

// ==================== REDUX STORE ====================
const authSlice = createSlice({
  name: 'auth',
  initialState: { user: null, token: null, isOnline: false },
  reducers: {
    setUser: (state, action) => { state.user = action.payload; },
    setToken: (state, action) => { state.token = action.payload; },
    setOnline: (state, action) => { state.isOnline = action.payload; },
    logout: (state) => { state.user = null; state.token = null; state.isOnline = false; },
  },
});

const ridesSlice = createSlice({
  name: 'rides',
  initialState: { currentRide: null, availableRides: [], rides: [], stats: {} },
  reducers: {
    setCurrentRide: (state, action) => { state.currentRide = action.payload; },
    setAvailableRides: (state, action) => { state.availableRides = action.payload; },
    setRides: (state, action) => { state.rides = action.payload; },
    setStats: (state, action) => { state.stats = action.payload; },
    clearCurrentRide: (state) => { state.currentRide = null; },
  },
});

const store = configureStore({
  reducer: {
    auth: authSlice.reducer,
    rides: ridesSlice.reducer,
  },
});

const { setUser, setToken, setOnline, logout } = authSlice.actions;
const { setCurrentRide, setAvailableRides, setRides, setStats, clearCurrentRide } = ridesSlice.actions;

// ==================== PANTALLA LOGIN ====================
const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();

  const handleLogin = async () => {
    if (!email || !password) return Alert.alert('Error', 'Completa todos los campos');
    try {
      setLoading(true);
      const res = await api.login(email, password);
      if (res.user.role !== 'driver') {
        return Alert.alert('Error', 'Esta app es solo para conductores');
      }
      dispatch(setUser(res.user));
      dispatch(setToken(res.access_token));
      navigation.replace('Home');
    } catch (error) {
      Alert.alert('Error', 'Credenciales inválidas');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.logo}>🚗 LlevameQ</Text>
      <Text style={styles.subtitle}>Conductor</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Contraseña"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      
      <TouchableOpacity style={styles.button} onPress={handleLogin} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Entrar</Text>}
      </TouchableOpacity>
      
      <TouchableOpacity onPress={() => navigation.navigate('Register')}>
        <Text style={styles.link}>¿No tienes cuenta? Regístrate</Text>
      </TouchableOpacity>
    </View>
  );
};

// ==================== PANTALLA REGISTRO ====================
const RegisterScreen = ({ navigation }) => {
  const [form, setForm] = useState({
    firstName: '', lastName: '', email: '', phone: '', password: '',
    vehiclePlate: '', vehicleModel: '', vehicleColor: '', licenseNumber: ''
  });
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();

  const handleRegister = async () => {
    if (!form.firstName || !form.email || !form.password || !form.vehiclePlate) {
      return Alert.alert('Error', 'Completa los campos obligatorios');
    }
    try {
      setLoading(true);
      const res = await api.register(form);
      dispatch(setUser(res.user));
      dispatch(setToken(res.access_token));
      navigation.replace('Home');
    } catch (error) {
      Alert.alert('Error', 'No se pudo registrar');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <Text style={styles.title}>Registro Conductor</Text>
      <TextInput style={styles.input} placeholder="Nombre *" onChangeText={(v) => setForm({...form, firstName: v})} />
      <TextInput style={styles.input} placeholder="Apellido" onChangeText={(v) => setForm({...form, lastName: v})} />
      <TextInput style={styles.input} placeholder="Email *" onChangeText={(v) => setForm({...form, email: v})} keyboardType="email-address" />
      <TextInput style={styles.input} placeholder="Teléfono *" onChangeText={(v) => setForm({...form, phone: v})} keyboardType="phone-pad" />
      <TextInput style={styles.input} placeholder="Contraseña *" onChangeText={(v) => setForm({...form, password: v})} secureTextEntry />
      
      <Text style={styles.sectionTitle}>Datos del Vehículo</Text>
      <TextInput style={styles.input} placeholder="Placa *" onChangeText={(v) => setForm({...form, vehiclePlate: v})} />
      <TextInput style={styles.input} placeholder="Modelo (ej: Honda XR150)" onChangeText={(v) => setForm({...form, vehicleModel: v})} />
      <TextInput style={styles.input} placeholder="Color" onChangeText={(v) => setForm({...form, vehicleColor: v})} />
      <TextInput style={styles.input} placeholder="Licencia de conducir" onChangeText={(v) => setForm({...form, licenseNumber: v})} />
      
      <TouchableOpacity style={styles.button} onPress={handleRegister} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Registrarse</Text>}
      </TouchableOpacity>
      
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={styles.link}>Ya tengo cuenta</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

// ==================== PANTALLA HOME (DASHBOARD) ====================
const HomeScreen = ({ navigation }) => {
  const user = useSelector(state => state.auth.user);
  const isOnline = useSelector(state => state.auth.isOnline);
  const stats = useSelector(state => state.rides.stats);
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadStats();
    if (user) {
      const ws = connectSocket(user.id);
      ws.on('new-ride-request', (data) => {
        Alert.alert('¡Nueva solicitud!', `Viaje de ${data.distanceKm}km - $${data.estimatedPrice}`, [
          { text: 'Ver', onPress: () => navigation.navigate('Available') }
        ]);
      });
    }
  }, [user]);

  const loadStats = async () => {
    try {
      const data = await api.getStats();
      dispatch(setStats(data));
    } catch (error) {
      console.error(error);
    }
  };

  const toggleOnline = async (value) => {
    try {
      setLoading(true);
      await api.updateStatus(value ? 'online' : 'offline');
      dispatch(setOnline(value));
      if (value) {
        // Simular actualización de ubicación
        await api.updateLocation(5.6902, -76.6589);
      }
    } catch (error) {
      Alert.alert('Error', 'No se pudo cambiar el estado');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Dashboard</Text>
      </View>
      
      <View style={styles.content}>
        <View style={styles.statusCard}>
          <Text style={styles.cardTitle}>Estado</Text>
          <View style={styles.statusRow}>
            <Text style={styles.statusText}>{isOnline ? '🟢 Online' : '🔴 Offline'}</Text>
            <Switch value={isOnline} onValueChange={toggleOnline} disabled={loading} />
          </View>
        </View>
        
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.totalRides || 0}</Text>
            <Text style={styles.statLabel}>Viajes</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>⭐ {stats.rating || '5.0'}</Text>
            <Text style={styles.statLabel}>Rating</Text>
          </View>
        </View>
        
        <TouchableOpacity
          style={[styles.button, !isOnline && styles.buttonDisabled]}
          onPress={() => navigation.navigate('Available')}
          disabled={!isOnline}
        >
          <Text style={styles.buttonText}>🔍 Ver Solicitudes Disponibles</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.secondaryButton}
          onPress={() => navigation.navigate('Earnings')}
        >
          <Text style={styles.secondaryButtonText}>💰 Ver Ganancias</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.secondaryButton}
          onPress={() => navigation.navigate('History')}
        >
          <Text style={styles.secondaryButtonText}>📋 Historial</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

// ==================== SOLICITUDES DISPONIBLES ====================
const AvailableRidesScreen = ({ navigation }) => {
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);
  const dispatch = useDispatch();

  useEffect(() => {
    loadRides();
  }, []);

  const loadRides = async () => {
    try {
      const data = await api.getRides();
      const available = data.filter(r => r.status === 'searching');
      setRides(available);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async (ride) => {
    try {
      await api.assignRide(ride.id);
      dispatch(setCurrentRide(ride));
      Alert.alert('¡Viaje asignado!', 'Dirígete al punto de origen', [
        { text: 'Ver viaje', onPress: () => navigation.navigate('ActiveRide') }
      ]);
    } catch (error) {
      Alert.alert('Error', 'No se pudo asignar el viaje');
    }
  };

  if (loading) return <View style={styles.center}><ActivityIndicator /></View>;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={{fontSize: 24, color: '#fff'}}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Solicitudes</Text>
      </View>
      
      {rides.length === 0 ? (
        <View style={styles.center}>
          <Text style={{fontSize: 60}}>🔍</Text>
          <Text>No hay solicitudes</Text>
        </View>
      ) : (
        <FlatList
          data={rides}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.rideCard}>
              <Text style={styles.cardTitle}>Nuevo viaje</Text>
              <Text>📍 {item.originAddress}</Text>
              <Text>🎯 {item.destinationAddress}</Text>
              <Text style={styles.distance}>{item.distanceKm} km • {item.estimatedDurationMinutes} min</Text>
              <Text style={styles.price}>${item.estimatedPrice}</Text>
              <TouchableOpacity style={styles.button} onPress={() => handleAccept(item)}>
                <Text style={styles.buttonText}>✅ Aceptar</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}
    </View>
  );
};

// ==================== VIAJE ACTIVO ====================
const ActiveRideScreen = ({ navigation }) => {
  const currentRide = useSelector(state => state.rides.currentRide);
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!currentRide) navigation.replace('Home');
  }, [currentRide]);

  const handleStart = async () => {
    try {
      setLoading(true);
      await api.startRide(currentRide.id);
      Alert.alert('¡Viaje iniciado!', 'Dirígete al destino');
      const updated = await api.getRideById(currentRide.id);
      dispatch(setCurrentRide(updated));
    } catch (error) {
      Alert.alert('Error', 'No se pudo iniciar');
    } finally {
      setLoading(false);
    }
  };

  const handleComplete = async () => {
    try {
      setLoading(true);
      await api.completeRide(currentRide.id);
      Alert.alert('¡Viaje completado!', `Ganaste $${currentRide.estimatedPrice}`);
      dispatch(clearCurrentRide());
      navigation.replace('Home');
    } catch (error) {
      Alert.alert('Error', 'No se pudo completar');
    } finally {
      setLoading(false);
    }
  };

  if (!currentRide) return null;

  return (
    <View style={styles.container}>
      <View style={[styles.statusBar, {backgroundColor: '#2196F3'}]}>
        <Text style={styles.statusText}>
          {currentRide.status === 'driver_assigned' && '🚗 Yendo al origen'}
          {currentRide.status === 'in_progress' && '✅ Viaje en curso'}
        </Text>
      </View>
      
      <View style={styles.mapPlaceholder}>
        <Text style={{fontSize: 60}}>🗺️</Text>
        <Text>Navegación GPS</Text>
      </View>
      
      <View style={styles.info}>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Pasajero</Text>
          <Text style={styles.cardText}>{currentRide.passenger.firstName} {currentRide.passenger.lastName}</Text>
          <Text>{currentRide.passenger.phone}</Text>
        </View>
        
        <View style={styles.card}>
          <Text>📍 {currentRide.originAddress}</Text>
          <Text>🎯 {currentRide.destinationAddress}</Text>
          <Text style={styles.price}>${currentRide.estimatedPrice}</Text>
        </View>
        
        {currentRide.status === 'driver_assigned' && (
          <TouchableOpacity style={styles.button} onPress={handleStart} disabled={loading}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>▶️ Iniciar Viaje</Text>}
          </TouchableOpacity>
        )}
        
        {currentRide.status === 'in_progress' && (
          <TouchableOpacity style={[styles.button, {backgroundColor: '#4CAF50'}]} onPress={handleComplete} disabled={loading}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>✅ Completar Viaje</Text>}
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
};

// ==================== GANANCIAS ====================
const EarningsScreen = ({ navigation }) => {
  const stats = useSelector(state => state.rides.stats);
  const [rides, setRides] = useState([]);

  useEffect(() => {
    loadRides();
  }, []);

  const loadRides = async () => {
    try {
      const data = await api.getRides();
      const completed = data.filter(r => r.status === 'completed');
      setRides(completed);
    } catch (error) {
      console.error(error);
    }
  };

  const totalEarnings = rides.reduce((sum, r) => sum + (r.finalPrice || 0), 0);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={{fontSize: 24, color: '#fff'}}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Ganancias</Text>
      </View>
      
      <View style={styles.content}>
        <View style={styles.earningsCard}>
          <Text style={styles.earningsTitle}>Total Ganado</Text>
          <Text style={styles.earningsAmount}>${totalEarnings}</Text>
          <Text style={styles.earningsSubtext}>{rides.length} viajes completados</Text>
        </View>
        
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.totalRides || 0}</Text>
            <Text style={styles.statLabel}>Total Viajes</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>⭐ {stats.rating || '5.0'}</Text>
            <Text style={styles.statLabel}>Rating</Text>
          </View>
        </View>
      </View>
    </View>
  );
};

// ==================== HISTORIAL ====================
const HistoryScreen = ({ navigation }) => {
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRides();
  }, []);

  const loadRides = async () => {
    try {
      const data = await api.getRides();
      setRides(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <View style={styles.center}><ActivityIndicator /></View>;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={{fontSize: 24, color: '#fff'}}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Historial</Text>
      </View>
      
      <FlatList
        data={rides}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.rideCard}>
            <Text style={styles.cardTitle}>{new Date(item.createdAt).toLocaleDateString()}</Text>
            <Text>📍 {item.originAddress}</Text>
            <Text>🎯 {item.destinationAddress}</Text>
            <Text style={styles.price}>${item.finalPrice || item.estimatedPrice}</Text>
            <Text style={{color: item.status === 'completed' ? '#4CAF50' : '#999'}}>
              {item.status === 'completed' ? '✅ Completado' : item.status}
            </Text>
          </View>
        )}
      />
    </View>
  );
};

// ==================== NAVEGACIÓN ====================
const Stack = createStackNavigator();

const AppContent = () => {
  const [isAuth, setIsAuth] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const token = await AsyncStorage.getItem('token');
    const userStr = await AsyncStorage.getItem('user');
    if (token && userStr) {
      const user = JSON.parse(userStr);
      if (user.role === 'driver') {
        store.dispatch(setUser(user));
        store.dispatch(setToken(token));
        setIsAuth(true);
      }
    }
    setChecking(false);
  };

  if (checking) return null;

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!isAuth ? (
          <>
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="Register" component={RegisterScreen} />
          </>
        ) : (
          <>
            <Stack.Screen name="Home" component={HomeScreen} />
            <Stack.Screen name="Available" component={AvailableRidesScreen} />
            <Stack.Screen name="ActiveRide" component={ActiveRideScreen} />
            <Stack.Screen name="Earnings" component={EarningsScreen} />
            <Stack.Screen name="History" component={HistoryScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

// ==================== APP PRINCIPAL ====================
const App = () => (
  <Provider store={store}>
    <AppContent />
  </Provider>
);

// ==================== ESTILOS ====================
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  scrollContainer: { flexGrow: 1, padding: 20, paddingTop: 60 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  logo: { fontSize: 48, textAlign: 'center', marginTop: 80, marginBottom: 10 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  subtitle: { fontSize: 18, textAlign: 'center', marginBottom: 40 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginTop: 20, marginBottom: 10 },
  input: { backgroundColor: '#f5f5f5', padding: 15, borderRadius: 10, marginBottom: 15 },
  button: { backgroundColor: '#000', padding: 15, borderRadius: 10, alignItems: 'center', marginBottom: 10 },
  buttonDisabled: { backgroundColor: '#999' },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  secondaryButton: { padding: 15, borderRadius: 10, alignItems: 'center', borderWidth: 1, borderColor: '#ddd', marginBottom: 10 },
  secondaryButtonText: { fontSize: 16 },
  link: { color: '#000', textAlign: 'center', marginTop: 15 },
  header: { flexDirection: 'row', alignItems: 'center', padding: 20, paddingTop: 60, backgroundColor: '#000' },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#fff', marginLeft: 10 },
  content: { flex: 1, padding: 20 },
  statusCard: { backgroundColor: '#f5f5f5', padding: 20, borderRadius: 10, marginBottom: 20 },
  cardTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 10 },
  statusRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  statusText: { fontSize: 18, fontWeight: 'bold' },
  statsRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 },
  statCard: { flex: 1, backgroundColor: '#f5f5f5', padding: 20, borderRadius: 10, marginHorizontal: 5, alignItems: 'center' },
  statNumber: { fontSize: 28, fontWeight: 'bold', marginBottom: 5 },
  statLabel: { fontSize: 14, color: '#666' },
  mapPlaceholder: { height: 250, backgroundColor: '#e0e0e0', justifyContent: 'center', alignItems: 'center' },
  info: { flex: 1, padding: 20 },
  card: { backgroundColor: '#f5f5f5', padding: 15, borderRadius: 10, marginBottom: 15 },
  cardText: { fontSize: 16, marginBottom: 5 },
  price: { fontSize: 24, fontWeight: 'bold', marginTop: 10 },
  distance: { color: '#666', marginVertical: 5 },
  statusBar: { padding: 20, paddingTop: 60, alignItems: 'center' },
  rideCard: { backgroundColor: '#f5f5f5', padding: 15, borderRadius: 10, marginBottom: 10, marginHorizontal: 20 },
  earningsCard: { backgroundColor: '#4CAF50', padding: 30, borderRadius: 10, alignItems: 'center', marginBottom: 20 },
  earningsTitle: { color: '#fff', fontSize: 16, marginBottom: 10 },
  earningsAmount: { color: '#fff', fontSize: 48, fontWeight: 'bold' },
  earningsSubtext: { color: '#fff', fontSize: 14, marginTop: 10 },
});

export default App;
