#!/bin/bash

# ========================================
# GENERAR APK - APP DE CONDUCTORES
# LlevameQ
# ========================================

echo "🚗 GENERANDO APK - APP DE CONDUCTORES"
echo "====================================="
echo ""

# Verificar directorio
if [ ! -f "package.json" ]; then
    echo "❌ Error: No estás en lleevameq-driver-app"
    exit 1
fi

# Pedir URL del backend
echo "🌐 IMPORTANTE: ¿Cuál es tu URL de Railway?"
echo "   Ejemplo: https://lleevameq-production-xxxx.up.railway.app"
read -p "URL del backend: " BACKEND_URL

if [ -z "$BACKEND_URL" ]; then
    echo "❌ Error: Debes ingresar la URL del backend"
    exit 1
fi

# Actualizar App.tsx
echo ""
echo "📝 Actualizando App.tsx con URL de producción..."

# Backup
cp App.tsx App.tsx.backup

# Actualizar URLs
sed -i.bak "s|const API_URL = 'http://.*';|const API_URL = '${BACKEND_URL}/api';|g" App.tsx
sed -i.bak "s|const WS_URL = 'http://.*';|const WS_URL = '${BACKEND_URL}';|g" App.tsx

echo "✅ App.tsx actualizado"
echo ""

# Ir a Android
cd android

# Limpiar build anterior
echo "🧹 Limpiando builds anteriores..."
./gradlew clean
echo "✅ Limpieza completada"
echo ""

# Generar APK
echo "🔨 Generando APK (esto puede tardar 2-3 minutos)..."
./gradlew assembleRelease

if [ $? -eq 0 ]; then
    echo ""
    echo "====================================="
    echo "✅ APK GENERADO EXITOSAMENTE"
    echo "====================================="
    echo ""
    echo "📦 Ubicación del APK:"
    echo "   android/app/build/outputs/apk/release/app-release.apk"
    echo ""
    echo "📱 Para instalar en tu celular:"
    echo "   1. Copia el APK a tu teléfono"
    echo "   2. Habilita 'Instalar apps desconocidas'"
    echo "   3. Abre el APK e instala"
    echo ""
    echo "🌐 Backend configurado:"
    echo "   ${BACKEND_URL}"
    echo ""
else
    echo ""
    echo "❌ Error al generar APK"
    echo "   Revisa los logs arriba"
    exit 1
fi
