# 🚗 LlevameQ - App de Conductores

App móvil completa para conductores del sistema LlevameQ (tipo DiDi) en Quibdó, Chocó.

## ✅ LO QUE INCLUYE

### Pantallas Completas
- ✅ Login / Registro
- ✅ Dashboard (online/offline)
- ✅ Solicitudes disponibles
- ✅ Viaje activo
- ✅ Ganancias
- ✅ Historial

### Funcionalidades
- ✅ Autenticación con JWT
- ✅ Toggle online/offline
- ✅ Recibir solicitudes en tiempo real
- ✅ Aceptar viajes
- ✅ Tracking de viajes
- ✅ WebSocket para notificaciones
- ✅ Panel de ganancias
- ✅ Historial completo

---

## 🚀 INSTALACIÓN RÁPIDA

### 1. Instalar dependencias

```bash
npm install
```

### 2. Configurar backend

Edita `App.tsx` y cambia estas líneas (cerca del principio):

```typescript
const API_URL = 'http://TU_IP:3000/api'; // Tu IP local
const WS_URL = 'http://TU_IP:3000';
```

**Para encontrar tu IP:**
- **Windows:** `ipconfig` (busca IPv4)
- **Mac/Linux:** `ifconfig` (busca inet)
- **Android Emulator:** usa `http://10.0.2.2:3000`
- **iOS Simulator:** usa `http://localhost:3000`

### 3. Iniciar el backend

```bash
cd ../lleevameq-backend
npm run start:dev
```

### 4. Iniciar la app

**Para Android:**
```bash
npx react-native run-android
```

**Para iOS:**
```bash
cd ios && pod install && cd ..
npx react-native run-ios
```

---

## 📱 USO DE LA APP

### Primera vez

1. **Registrarse como conductor:**
   - Tap en "¿No tienes cuenta? Regístrate"
   - Completa datos personales
   - **Completa datos del vehículo:**
     - Placa (obligatorio)
     - Modelo (ej: Honda XR150)
     - Color
     - Licencia de conducir

2. **Activar modo online:**
   - En el Dashboard, activa el switch
   - Esto te pone "disponible" para recibir viajes
   - Tu ubicación se actualiza automáticamente

3. **Recibir solicitudes:**
   - Cuando un pasajero solicita viaje
   - Recibes notificación en tiempo real
   - Puedes ver todas las solicitudes disponibles

4. **Aceptar viaje:**
   - Tap en "Ver Solicitudes Disponibles"
   - Revisa detalles (distancia, tarifa)
   - Tap en "Aceptar"

5. **Durante el viaje:**
   - Te diriges al punto de origen
   - Tap "Iniciar Viaje" cuando llegues
   - Navegas al destino
   - Tap "Completar Viaje" cuando termines

6. **Ganancias:**
   - Ve tus ganancias totales
   - Revisa viajes completados
   - Estadísticas de rating

---

## 🎯 FLUJO COMPLETO DE CONDUCTOR

```
1. Login → Dashboard
2. Activar Online 🟢
3. Esperar solicitudes
4. Ver solicitud → Aceptar ✅
5. Ir al origen 🚗
6. Iniciar viaje ▶️
7. Ir al destino 🎯
8. Completar viaje ✅
9. Recibir pago 💰
```

---

## 🔧 CONFIGURACIÓN AVANZADA

### Actualización automática de ubicación

El sistema actualiza tu ubicación cada 5 segundos cuando estás:
- Online
- Con un viaje activo
- En la app

### Radio de matching

El backend busca pasajeros en un radio de 5km de tu ubicación actual.

### Notificaciones en tiempo real

WebSocket te notifica cuando:
- Hay nueva solicitud de viaje
- Estado del viaje cambia
- Pasajero cancela

---

## 📂 ESTRUCTURA

```
App.tsx                    # Todo el código de la app
├─ Configuración
├─ Servicios (API, WebSocket)
├─ Redux Store
├─ Pantallas:
│  ├─ LoginScreen
│  ├─ RegisterScreen
│  ├─ HomeScreen (Dashboard)
│  ├─ AvailableRidesScreen
│  ├─ ActiveRideScreen
│  ├─ EarningsScreen
│  └─ HistoryScreen
├─ Navegación
└─ Estilos
```

---

## 💰 SISTEMA DE GANANCIAS

El sistema calcula automáticamente:

```
Tarifa Base:     $3,000 COP
Por kilómetro:   $1,500 COP/km
Por minuto:      $200 COP/min
Tarifa mínima:   $4,000 COP

Recargos:
- Nocturno (22:00-06:00):  +20%
- Hora pico (7-9, 17-19):  +30%
```

**Toda la tarifa va para el conductor** (en este sistema base).

---

## 🐛 SOLUCIÓN DE PROBLEMAS

### No recibo notificaciones de viajes

1. Verifica que estés en modo "Online" 🟢
2. Revisa conexión WebSocket en logs
3. Verifica que el backend esté corriendo
4. Actualiza tu ubicación manualmente

### Error al aceptar viaje

1. Puede que otro conductor lo aceptó primero
2. Verifica tu conexión a internet
3. Refresca la lista de solicitudes

### GPS no funciona

1. Verifica permisos de ubicación
2. En Android: Settings → Apps → LlevameQ → Permissions
3. En iOS: Settings → Privacy → Location Services

---

## 📊 MÉTRICAS

```
Pantallas:     6
Componentes:   Integrados en App.tsx
Líneas:        ~650 líneas
Peso APK:      ~20-30 MB
```

---

## 🎯 DIFERENCIAS CON APP DE PASAJEROS

| Característica | Pasajero | Conductor |
|----------------|----------|-----------|
| Solicitar viaje | ✅ | ❌ |
| Aceptar solicitud | ❌ | ✅ |
| Toggle online/offline | ❌ | ✅ |
| Ver ganancias | ❌ | ✅ |
| Tracking GPS | Ver | Enviar |
| Notificaciones | Conductor asignado | Nueva solicitud |

---

## 💡 TIPS PARA CONDUCTORES

- ✅ **Mantente online** en zonas con mucha demanda
- ✅ **Responde rápido** a las solicitudes (30 segundos)
- ✅ **Mantén buen rating** (>4.5 estrellas)
- ✅ **Actualiza tu ubicación** antes de ponerte online
- ✅ **Revisa tu vehículo** antes de cada viaje

---

## 🆘 AYUDA RÁPIDA

**No aparecen solicitudes:**
- Verifica que estés online 🟢
- Puede que no haya viajes cerca
- Espera unos minutos

**Error "No puedes aceptar este viaje":**
- Otro conductor lo aceptó primero
- Refresca la lista

**WebSocket desconectado:**
```bash
# Reinicia la app
# Verifica el backend esté corriendo
```

---

## ✨ RESUMEN

```
✅ App completa para conductores
✅ 6 pantallas implementadas
✅ Sistema de ganancias
✅ Toggle online/offline
✅ WebSocket en tiempo real
✅ Conectada al backend
✅ Lista para usar
```

---

**¡A trabajar y ganar dinero! 💰**

Creado para Que - LlevameQ Quibdó, Chocó 🚗
