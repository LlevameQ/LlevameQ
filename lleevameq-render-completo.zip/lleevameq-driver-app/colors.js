// 🎨 COLORES OFICIALES LLEVAMEQ
// Basados en el logo oficial

export const Colors = {
  // ============================================
  // COLORES PRIMARIOS (del logo)
  // ============================================
  primary: '#FF5722',      // Naranja/Rojo vibrante
  secondary: '#26C6DA',    // Turquesa/Cyan
  dark: '#212121',         // Negro/Gris oscuro
  
  // ============================================
  // COLORES NEUTROS
  // ============================================
  background: '#F5F5F5',   // Gris muy claro
  backgroundDark: '#EEEEEE', // Gris claro
  white: '#FFFFFF',
  black: '#000000',
  
  // ============================================
  // ESTADOS
  // ============================================
  success: '#4CAF50',      // Verde - Éxito
  warning: '#FF9800',      // Naranja - Advertencia
  error: '#F44336',        // Rojo - Error
  info: '#2196F3',         // Azul - Info
  
  // ============================================
  // TEXTO
  // ============================================
  textPrimary: '#212121',   // Texto principal
  textSecondary: '#757575', // Texto secundario
  textLight: '#FFFFFF',     // Texto sobre fondos oscuros
  textDisabled: '#BDBDBD',  // Texto deshabilitado
  
  // ============================================
  // BORDES Y SOMBRAS
  // ============================================
  border: '#E0E0E0',        // Bordes
  borderLight: '#F5F5F5',   // Bordes claros
  shadow: '#00000029',      // Sombras
  
  // ============================================
  // GRADIENTES
  // ============================================
  gradientStart: '#FF5722',
  gradientEnd: '#FF8A65',
  
  // ============================================
  // TRANSPARENCIAS
  // ============================================
  overlay: 'rgba(0, 0, 0, 0.5)',
  overlayLight: 'rgba(0, 0, 0, 0.3)',
};

// ============================================
// TEMAS
// ============================================

export const Theme = {
  // Botón Primario
  buttonPrimary: {
    backgroundColor: Colors.primary,
    color: Colors.white,
  },
  
  // Botón Secundario
  buttonSecondary: {
    backgroundColor: Colors.secondary,
    color: Colors.white,
  },
  
  // Botón Outline
  buttonOutline: {
    backgroundColor: 'transparent',
    borderColor: Colors.primary,
    color: Colors.primary,
  },
  
  // Header
  header: {
    backgroundColor: Colors.dark,
    color: Colors.white,
  },
  
  // Card
  card: {
    backgroundColor: Colors.white,
    borderColor: Colors.border,
    shadowColor: Colors.shadow,
  },
  
  // Input
  input: {
    backgroundColor: Colors.white,
    borderColor: Colors.border,
    color: Colors.textPrimary,
    placeholderColor: Colors.textSecondary,
  },
};

export default Colors;
