import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
  FlatList,
  ScrollView,
  Dimensions,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Provider, useSelector, useDispatch } from 'react-redux';
import { configureStore, createSlice } from '@reduxjs/toolkit';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { io } from 'socket.io-client';

// ==================== CONFIGURACIÓN ====================
const API_URL = 'http://localhost:3000/api'; // Cambiar por tu IP
const WS_URL = 'http://localhost:3000';

// ==================== SERVICIOS ====================
const apiClient = axios.create({
  baseURL: API_URL,
  timeout: 10000,
});

apiClient.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

const api = {
  login: async (email, password) => {
    const res = await apiClient.post('/auth/login', { email, password });
    await AsyncStorage.setItem('token', res.data.access_token);
    await AsyncStorage.setItem('user', JSON.stringify(res.data.user));
    return res.data;
  },
  register: async (data) => {
    const res = await apiClient.post('/auth/register', data);
    await AsyncStorage.setItem('token', res.data.access_token);
    await AsyncStorage.setItem('user', JSON.stringify(res.data.user));
    return res.data;
  },
  createRide: (data) => apiClient.post('/rides', data).then(r => r.data),
  getRides: () => apiClient.get('/rides').then(r => r.data),
  getRideById: (id) => apiClient.get(`/rides/${id}`).then(r => r.data),
  cancelRide: (id, reason) => apiClient.post(`/rides/${id}/cancel`, { reason }).then(r => r.data),
  rateRide: (id, rating, comment) => apiClient.post(`/rides/${id}/rate`, { rating, comment }).then(r => r.data),
};

// ==================== WEBSOCKET ====================
let socket = null;
const connectSocket = (userId) => {
  if (!socket) {
    socket = io(WS_URL);
    socket.on('connect', () => {
      socket.emit('authenticate', { userId });
      console.log('Socket conectado');
    });
  }
  return socket;
};

// ==================== REDUX STORE ====================
const authSlice = createSlice({
  name: 'auth',
  initialState: { user: null, token: null },
  reducers: {
    setUser: (state, action) => { state.user = action.payload; },
    setToken: (state, action) => { state.token = action.payload; },
    logout: (state) => { state.user = null; state.token = null; },
  },
});

const ridesSlice = createSlice({
  name: 'rides',
  initialState: { currentRide: null, rides: [], driverLocation: null },
  reducers: {
    setCurrentRide: (state, action) => { state.currentRide = action.payload; },
    setRides: (state, action) => { state.rides = action.payload; },
    setDriverLocation: (state, action) => { state.driverLocation = action.payload; },
    clearCurrentRide: (state) => { state.currentRide = null; state.driverLocation = null; },
  },
});

const store = configureStore({
  reducer: {
    auth: authSlice.reducer,
    rides: ridesSlice.reducer,
  },
});

const { setUser, setToken, logout } = authSlice.actions;
const { setCurrentRide, setRides, setDriverLocation, clearCurrentRide } = ridesSlice.actions;

// ==================== PANTALLA LOGIN ====================
const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();

  const handleLogin = async () => {
    if (!email || !password) return Alert.alert('Error', 'Completa todos los campos');
    try {
      setLoading(true);
      const res = await api.login(email, password);
      dispatch(setUser(res.user));
      dispatch(setToken(res.access_token));
      navigation.replace('Home');
    } catch (error) {
      Alert.alert('Error', 'Credenciales inválidas');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.logo}>🚗 LlevameQ</Text>
      <Text style={styles.subtitle}>Pasajero</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Contraseña"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      
      <TouchableOpacity style={styles.button} onPress={handleLogin} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Entrar</Text>}
      </TouchableOpacity>
      
      <TouchableOpacity onPress={() => navigation.navigate('Register')}>
        <Text style={styles.link}>¿No tienes cuenta? Regístrate</Text>
      </TouchableOpacity>
    </View>
  );
};

// ==================== PANTALLA REGISTRO ====================
const RegisterScreen = ({ navigation }) => {
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', phone: '', password: '' });
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();

  const handleRegister = async () => {
    if (!form.firstName || !form.email || !form.password) {
      return Alert.alert('Error', 'Completa todos los campos');
    }
    try {
      setLoading(true);
      const res = await api.register({ ...form, role: 'passenger' });
      dispatch(setUser(res.user));
      dispatch(setToken(res.access_token));
      navigation.replace('Home');
    } catch (error) {
      Alert.alert('Error', 'No se pudo registrar');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Crear Cuenta</Text>
      <TextInput style={styles.input} placeholder="Nombre" onChangeText={(v) => setForm({...form, firstName: v})} />
      <TextInput style={styles.input} placeholder="Apellido" onChangeText={(v) => setForm({...form, lastName: v})} />
      <TextInput style={styles.input} placeholder="Email" onChangeText={(v) => setForm({...form, email: v})} keyboardType="email-address" />
      <TextInput style={styles.input} placeholder="Teléfono" onChangeText={(v) => setForm({...form, phone: v})} keyboardType="phone-pad" />
      <TextInput style={styles.input} placeholder="Contraseña" onChangeText={(v) => setForm({...form, password: v})} secureTextEntry />
      
      <TouchableOpacity style={styles.button} onPress={handleRegister} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Registrarse</Text>}
      </TouchableOpacity>
      
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={styles.link}>Ya tengo cuenta</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

// ==================== PANTALLA HOME ====================
const HomeScreen = ({ navigation }) => {
  const user = useSelector(state => state.auth.user);
  const dispatch = useDispatch();
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      const ws = connectSocket(user.id);
      ws.on('driver-assigned', (data) => {
        Alert.alert('¡Conductor asignado!', `${data.driver.firstName} va hacia ti`);
      });
    }
  }, [user]);

  const handleRequestRide = async () => {
    if (!origin || !destination) return Alert.alert('Error', 'Ingresa origen y destino');
    
    try {
      setLoading(true);
      const ride = await api.createRide({
        originLat: 5.6902,
        originLng: -76.6589,
        originAddress: origin,
        destinationLat: 5.6950,
        destinationLng: -76.6600,
        destinationAddress: destination,
        paymentMethod: 'cash',
      });
      
      dispatch(setCurrentRide(ride));
      Alert.alert('¡Viaje creado!', `Tarifa: $${ride.estimatedPrice}`, [
        { text: 'Ver estado', onPress: () => navigation.navigate('ActiveRide') }
      ]);
    } catch (error) {
      Alert.alert('Error', 'No se pudo crear el viaje');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>¡Hola {user?.firstName}! 👋</Text>
      </View>
      
      <View style={styles.mapPlaceholder}>
        <Text style={{fontSize: 60}}>🗺️</Text>
        <Text>Mapa de Quibdó</Text>
      </View>
      
      <View style={styles.form}>
        <View style={styles.inputRow}>
          <Text style={{fontSize: 20, marginRight: 10}}>📍</Text>
          <TextInput
            style={[styles.input, {flex: 1}]}
            placeholder="¿Dónde estás?"
            value={origin}
            onChangeText={setOrigin}
          />
        </View>
        
        <View style={styles.inputRow}>
          <Text style={{fontSize: 20, marginRight: 10}}>🎯</Text>
          <TextInput
            style={[styles.input, {flex: 1}]}
            placeholder="¿A dónde vas?"
            value={destination}
            onChangeText={setDestination}
          />
        </View>
        
        <TouchableOpacity style={styles.button} onPress={handleRequestRide} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Solicitar Viaje</Text>}
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.secondaryButton} onPress={() => navigation.navigate('History')}>
          <Text style={styles.secondaryButtonText}>📋 Ver Historial</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

// ==================== PANTALLA VIAJE ACTIVO ====================
const ActiveRideScreen = ({ navigation }) => {
  const currentRide = useSelector(state => state.rides.currentRide);
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!currentRide) navigation.replace('Home');
  }, [currentRide]);

  const handleCancel = async () => {
    Alert.alert('Cancelar', '¿Seguro?', [
      { text: 'No', style: 'cancel' },
      {
        text: 'Sí',
        onPress: async () => {
          try {
            setLoading(true);
            await api.cancelRide(currentRide.id, 'Cancelado por pasajero');
            dispatch(clearCurrentRide());
            navigation.replace('Home');
          } catch (error) {
            Alert.alert('Error', 'No se pudo cancelar');
          } finally {
            setLoading(false);
          }
        }
      }
    ]);
  };

  if (!currentRide) return null;

  return (
    <View style={styles.container}>
      <View style={[styles.statusBar, {backgroundColor: '#4CAF50'}]}>
        <Text style={styles.statusText}>
          {currentRide.status === 'searching' && '🔍 Buscando conductor...'}
          {currentRide.status === 'driver_assigned' && '🚗 Conductor asignado'}
          {currentRide.status === 'in_progress' && '✅ Viaje en curso'}
        </Text>
      </View>
      
      <View style={styles.mapPlaceholder}>
        <Text style={{fontSize: 60}}>🗺️</Text>
        <Text>Tracking GPS</Text>
      </View>
      
      <View style={styles.info}>
        {currentRide.driver && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Conductor</Text>
            <Text style={styles.cardText}>{currentRide.driver.firstName} {currentRide.driver.lastName}</Text>
            <Text>{currentRide.driver.vehicleModel} - {currentRide.driver.vehiclePlate}</Text>
          </View>
        )}
        
        <View style={styles.card}>
          <Text>📍 {currentRide.originAddress}</Text>
          <Text>🎯 {currentRide.destinationAddress}</Text>
          <Text style={styles.price}>${currentRide.estimatedPrice}</Text>
        </View>
        
        {currentRide.status !== 'in_progress' && (
          <TouchableOpacity style={[styles.button, {backgroundColor: '#f44336'}]} onPress={handleCancel} disabled={loading}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Cancelar Viaje</Text>}
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
};

// ==================== PANTALLA HISTORIAL ====================
const HistoryScreen = ({ navigation }) => {
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRides();
  }, []);

  const loadRides = async () => {
    try {
      const data = await api.getRides();
      setRides(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <View style={styles.center}><ActivityIndicator /></View>;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={{fontSize: 24}}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Historial</Text>
      </View>
      
      {rides.length === 0 ? (
        <View style={styles.center}>
          <Text style={{fontSize: 60}}>📋</Text>
          <Text>No tienes viajes</Text>
        </View>
      ) : (
        <FlatList
          data={rides}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.rideCard}>
              <Text style={styles.cardTitle}>{new Date(item.createdAt).toLocaleDateString()}</Text>
              <Text>📍 {item.originAddress}</Text>
              <Text>🎯 {item.destinationAddress}</Text>
              <Text style={styles.price}>${item.finalPrice || item.estimatedPrice}</Text>
              <Text style={{color: item.status === 'completed' ? '#4CAF50' : '#999'}}>
                {item.status === 'completed' ? '✅ Completado' : item.status}
              </Text>
            </View>
          )}
        />
      )}
    </View>
  );
};

// ==================== NAVEGACIÓN ====================
const Stack = createStackNavigator();

const AppContent = () => {
  const [isAuth, setIsAuth] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const token = await AsyncStorage.getItem('token');
    const userStr = await AsyncStorage.getItem('user');
    if (token && userStr) {
      store.dispatch(setUser(JSON.parse(userStr)));
      store.dispatch(setToken(token));
      setIsAuth(true);
    }
    setChecking(false);
  };

  if (checking) return null;

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!isAuth ? (
          <>
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="Register" component={RegisterScreen} />
          </>
        ) : (
          <>
            <Stack.Screen name="Home" component={HomeScreen} />
            <Stack.Screen name="ActiveRide" component={ActiveRideScreen} />
            <Stack.Screen name="History" component={HistoryScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

// ==================== APP PRINCIPAL ====================
const App = () => (
  <Provider store={store}>
    <AppContent />
  </Provider>
);

// ==================== ESTILOS ====================
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  logo: { fontSize: 48, textAlign: 'center', marginBottom: 10 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  subtitle: { fontSize: 18, textAlign: 'center', marginBottom: 40 },
  input: { backgroundColor: '#f5f5f5', padding: 15, borderRadius: 10, marginBottom: 15 },
  inputRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  button: { backgroundColor: '#000', padding: 15, borderRadius: 10, alignItems: 'center', marginBottom: 10 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  secondaryButton: { padding: 15, borderRadius: 10, alignItems: 'center', borderWidth: 1, borderColor: '#ddd' },
  secondaryButtonText: { fontSize: 16 },
  link: { color: '#000', textAlign: 'center', marginTop: 15 },
  header: { flexDirection: 'row', alignItems: 'center', padding: 20, paddingTop: 60, backgroundColor: '#000' },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#fff', marginLeft: 10 },
  mapPlaceholder: { height: 250, backgroundColor: '#e0e0e0', justifyContent: 'center', alignItems: 'center' },
  form: { padding: 20 },
  info: { flex: 1, padding: 20 },
  card: { backgroundColor: '#f5f5f5', padding: 15, borderRadius: 10, marginBottom: 15 },
  cardTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 5 },
  cardText: { fontSize: 14 },
  price: { fontSize: 24, fontWeight: 'bold', marginTop: 10 },
  statusBar: { padding: 20, paddingTop: 60, alignItems: 'center' },
  statusText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  rideCard: { backgroundColor: '#f5f5f5', padding: 15, borderRadius: 10, marginBottom: 10, marginHorizontal: 20 },
});

export default App;
