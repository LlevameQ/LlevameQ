# Configuración de firma para Release APK
# LlevameQ - App de Pasajeros

## IMPORTANTE: Generar KeyStore

Para generar APK firmado para producción, necesitas un keystore:

```bash
# Generar keystore (solo una vez)
keytool -genkeypair -v -storetype PKCS12 \
  -keystore lleevameq-passenger.keystore \
  -alias lleevameq-passenger \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000

# Te pedirá:
# - Password del keystore (guárdalo bien)
# - Nombre completo
# - Organización: LlevameQ
# - Ciudad: Quibdó
# - Estado: Chocó
# - País: CO
```

## Configurar en android/app/build.gradle

Agrega en `android/app/build.gradle`:

```gradle
android {
    ...
    signingConfigs {
        release {
            storeFile file('lleevameq-passenger.keystore')
            storePassword 'TU_PASSWORD'
            keyAlias 'lleevameq-passenger'
            keyPassword 'TU_PASSWORD'
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
```

## NOTA DE SEGURIDAD

⚠️ NUNCA subas el keystore a Git
⚠️ NUNCA compartas el password
⚠️ Guarda copias del keystore en lugares seguros

Sin el keystore original, NO PODRÁS actualizar la app en Google Play.

## Para desarrollo (APK sin firma)

El APK debug funciona sin keystore:
```bash
./gradlew assembleRelease
```
