import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { RidesModule } from './rides/rides.module';
import { User } from './users/entities/user.entity';
import { Ride } from './rides/entities/ride.entity';

@Module({
  imports: [
    // Configuración global
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),

    // Base de datos TypeORM
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => ({
        type: 'postgres',
        // Railway usa DATABASE_URL, local usa variables separadas
        url: configService.get('DATABASE_URL'),
        host: configService.get('DATABASE_HOST') || 'localhost',
        port: parseInt(configService.get('DATABASE_PORT')) || 5432,
        username: configService.get('DATABASE_USER') || 'lleevameq',
        password: configService.get('DATABASE_PASSWORD') || 'lleevameq123',
        database: configService.get('DATABASE_NAME') || 'lleevameq',
        entities: [User, Ride],
        synchronize: true, // ⚠️ Solo en desarrollo! En producción usar migrations
        logging: configService.get('NODE_ENV') === 'development',
        ssl: configService.get('NODE_ENV') === 'production' 
          ? { rejectUnauthorized: false }
          : false,
      }),
      inject: [ConfigService],
    }),

    // Módulos de la aplicación
    AuthModule,
    UsersModule,
    RidesModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
